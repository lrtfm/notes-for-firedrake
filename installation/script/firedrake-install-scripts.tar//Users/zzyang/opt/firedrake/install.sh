#!/bin/bash

set -e  # exit on error

# We assume the patches fold is in the dir which contains this script
PATCH_DIR=$(dirname $(readlink -f $0))/patches/

# DIR to install firedrake. You could change it.
OPT=$HOME/opt/firedrake

# This is the dir you store the packages that petsc depends on.
# PETSc will download the packages if its not set or empty.
# PETSC_PKG_DIR=$OPT/petsc-download-dep/pkgs

curl -O https://raw.githubusercontent.com/firedrakeproject/firedrake/master/scripts/firedrake-install

sed -i.bak \
    -e 's/\(--with-debugging=\)0/\11/g' \
    -e 's/\(--with-x=\)0/\11/g' \
    -e '/with environment(MACOSX/a\
            check_call(["git", "apply", "'${PATCH_DIR//\//\\\/}'petsc-slepc.patch"])\
            check_call(["git", "apply", "'${PATCH_DIR//\//\\\/}'petsc-chaco.patch"])' \
    -e 's/\(CFLAGS=-Wno.*\)"/\1 -Wno-int-conversion"/' \
    -e 's/\(^.*\)\(for p in ("PyOP2", "firedrake"):\)/\1with directory("firedrake"):\
\1    check_call(["git", "apply", "'${PATCH_DIR//\//\\\/}'firedrake.patch"])\
\1\2/'\
    firedrake-install


install_slepc4py () {
    source $1
    export PETSC_DIR=$(readlink -f $(dirname `which python`)/../src/petsc)
    export PETSC_ARCH=default
    export SLEPC_DIR="$(find $PETSC_DIR/$PETSC_ARCH/externalpackages \
                             -maxdepth 1 -name '*slepc*')"
    python -m pip install \
        --no-build-isolation \
        --no-binary mpi4py,randomgen,numpy \
        --no-deps -vvv --ignore-installed \
        $SLEPC_DIR/src/binding/slepc4py
    unset PETSC_DIR
    unset PETSC_ARCH
    unset SLEPC_DIR
    deactivate
}

PETSC_CONFIGURE_OPTIONS_BASE="\
    --download-fftw \
    --download-mmg \
    --download-p4est \
    --download-parmmg \
    --download-triangle \
    --download-tetgen \
    --download-ctetgen \
    --download-hpddm \
    --download-libpng \
    --download-slepc \
"

if [[ ! -z "$PETSC_PKG_DIR" ]]
then
    PETSC_CONFIGURE_OPTIONS_BASE="$PETSC_CONFIGURE_OPTIONS_BASE \
        --with-packages-download-dir=$PETSC_PKG_DIR \
    "
fi

# echo $PETSC_CONFIGURE_OPTIONS_BASE

install_firedrake_real() {
    R_NAME=firedrake-real-int32-debug
    
    PETSC_CONFIGURE_OPTIONS="$PETSC_CONFIGURE_OPTIONS_BASE \
        --download-pragmatic \
        --download-eigen \
    " \
    python3.11 firedrake-install \
        --disable-ssh \
        --documentation-dependencies \
        --netgen \
        --venv-name $OPT/$R_NAME
    
    install_slepc4py $OPT/$R_NAME/bin/activate
}

install_firedrake_complex() {
    C_NAME=firedrake-complex-int32-debug
    
    PETSC_CONFIGURE_OPTIONS="$PETSC_CONFIGURE_OPTIONS_BASE \
    " \
    python3.11 firedrake-install \
        --disable-ssh \
        --documentation-dependencies  \
        --netgen \
        --petsc-int-type int32 --complex \
        --venv-name $OPT/$C_NAME
    
    install_slepc4py $OPT/$C_NAME/bin/activate
}

# install the real version
time install_firedrake_real

# install the complex version
time install_firedrake_complex
