#!/bin/bash

set -e  # exit on error

# We assume the patches fold is in the dir which contains this script
PATCH_DIR=$(dirname $(readlink -f $0))/patches/

# DIR to install firedrake. You could change it.
OPT=$HOME/opt/firedrake
VERSION=real
SUFFIX=""

# Install firedrake with old petsc as mumps raise error in the current version petsc
PETSC_BRANCH="--package-branch petsc fe466959bc653a84ee2ebebfdc0f6a9532500c2e"

# This is the dir you store the packages that petsc depends on.
# PETSc will download the packages if its not set or empty.
# WARNING: There is a bug in this option, so we DO NOT use it.
# PETSC_PKG_DIR=$OPT/petsc-download-dep/pkgs

help()
{
    echo ""
    echo "Install firedrake with some patches on MacOS"
    echo "The path of firedrake will be <path-to-install>/firedrake-<version>-int32-debug<venv-suffix>"
    echo
    echo "Syntax: $0 [-h|v|p|s|n]"
    echo "options:"
    echo "    -h                    Print this help."
    echo "    -v <version>          Version to install. can be real, complex or all"
    echo "    -p <path-to-install>  Install the firedrake venv in path. default: ~/opt/firedrake"
    echo "    -s <venv-suffix>      Firedrake venv name. default: firedrake-<version>-int32-debug"
    echo "    -n                    Dry run: print the install path and exit."
}

while getopts ":hv:p:s:n" option; do
    case $option in
        h) # display help
            help
            exit;;
        v)
            VERSION=$OPTARG
            ;;
        p)
            OPT=$OPTARG
            ;;
        s)
            SUFFIX=$OPTARG
            ;;
        n)
            DRYRUN=true
            ;;
        \?) # Invalid option
            echo "Error: Invalid option"
            exit;;
    esac
done

VS="real complex all"
if [[ ! $VS =~ (^|[[:space:]])$VERSION($|[[:space:]]) ]]; then
    echo "Error: Version must in (real, complex, all). You input $VERSION."
    exit -1
fi

echo "Will install firedarke version ${VERSION/all/(real,complex)} in path $OPT with suffix ${SUFFIX:-null}"
echo "The path will be $OPT/firedrake-${VERSION/all/<real|complex>}-int32-debug$SUFFIX"

if [[ $DRYRUN == true ]]; then
    exit 0
fi

# download the install script
curl -O https://raw.githubusercontent.com/firedrakeproject/firedrake/master/scripts/firedrake-install

# Generate the petsc-slepc patch
sed 's/<<<REPLACE>>>/'${PATCH_DIR//\//\\\/}'/' "${PATCH_DIR}petsc-slepc.patch.in" > "${PATCH_DIR}petsc-slepc.patch"

# cat << EOF
# Below, we use `Here document` to add comments to the command of sed
sed -i.bak -f - firedrake-install << EOF
# Enable debug
s/\(--with-debugging=\)0/\11/g
# Install X with petsc (Need to install libX)
# s/\(--with-x=\)0/\11/g
# Patch slepc and chaco
/with environment(MACOSX/a\\
            # Patch slepc\\
            check_call(["git", "apply", "${PATCH_DIR}petsc-slepc.patch"])\\
            # Patch chaco\\
            check_call(["git", "apply", "${PATCH_DIR}petsc-chaco.patch"])
# Flag for openblas
s/\(CFLAGS=-Wno.*\)"/\1 -Wno-int-conversion"/
# for apple linker (disalbe now)
# s/^\( \{1,\}\).*"--LDFLAGS=-Wl,-ld_classic".*$/\1pass/
# patch firedrake
s/\(^.*\)\(for p in ("PyOP2", "firedrake"):\)/\1with directory("firedrake"):\\
\1    check_call(["git", "apply", "${PATCH_DIR//\//\\/}firedrake.patch"])\\
\1\2/
EOF

install_slepc4py () {
    source $1
    export PETSC_DIR=$(readlink -f $(dirname `which python`)/../src/petsc)
    export PETSC_ARCH=default
    export SLEPC_DIR="$(find $PETSC_DIR/$PETSC_ARCH/externalpackages \
                             -maxdepth 1 -name '*slepc*')"
    echo "Install slepc4py..."
    python -m pip install \
        --log $PETSC_DIR/../../slepc4py-install.log \
        --no-build-isolation \
        --no-binary mpi4py,randomgen,numpy \
        --no-deps -q --ignore-installed \
        $SLEPC_DIR/src/binding/slepc4py
    echo "The slepc4py's log saved in $(readlink -f $PETSC_DIR/../../slepc4py-install.log)"
    unset PETSC_DIR
    unset PETSC_ARCH
    unset SLEPC_DIR
    deactivate
}

PETSC_CONFIGURE_OPTIONS_BASE="\
    --download-fftw \
    --download-mmg \
    --download-p4est \
    --download-parmmg \
    --download-triangle \
    --download-tetgen \
    --download-ctetgen \
    --download-hpddm \
    --download-libpng \
    --download-slepc \
"

if [[ ! -z "$PETSC_PKG_DIR" ]]
then
    PETSC_CONFIGURE_OPTIONS_BASE="$PETSC_CONFIGURE_OPTIONS_BASE \
        --with-packages-download-dir=$PETSC_PKG_DIR \
    "
fi

# echo $PETSC_CONFIGURE_OPTIONS_BASE

copy_install_script_and_log() {
    echo Copy install script and log to $OPT/$1/
    cp ./firedrake-install{,.log} $OPT/$1/
}

install_firedrake_real() {
    R_NAME=firedrake-real-int32-debug${SUFFIX}

    PETSC_CONFIGURE_OPTIONS="$PETSC_CONFIGURE_OPTIONS_BASE \
        --download-pragmatic \
        --download-eigen \
    " \
    python3.11 firedrake-install \
        ${PETSC_BRANCH} \
        --disable-ssh \
        --documentation-dependencies \
        --netgen \
        --venv-name $OPT/$R_NAME

    copy_install_script_and_log $R_NAME

    install_slepc4py $OPT/$R_NAME/bin/activate
}

install_firedrake_complex() {
    C_NAME=firedrake-complex-int32-debug${SUFFIX}

    PETSC_CONFIGURE_OPTIONS="$PETSC_CONFIGURE_OPTIONS_BASE \
    " \
    python3.11 firedrake-install \
        ${PETSC_BRANCH} \
        --disable-ssh \
        --documentation-dependencies  \
        --netgen \
        --petsc-int-type int32 --complex \
        --venv-name $OPT/$C_NAME

    copy_install_script_and_log $C_NAME

    install_slepc4py $OPT/$C_NAME/bin/activate
}

# install the real version
if [[ $VERSION == real || $VERSION == all ]]; then
    echo "Install firedrake real version..."
    time install_firedrake_real
fi

# install the complex version
if [[ $VERSION == complex || $VERSION == all ]]; then
    echo "Install firedrake complex version..."
    time install_firedrake_complex
fi
