# Install Firedrake

See the help of `install.sh`
```
./install.sh -h
```

Command to make archive of current snapshot
```
git archive -o firedrake-install-scripts.tar --prefix=firedrake-install-scripts/ HEAD
```
